var but=document.querySelector(".ds");
but.addEventListener("click",saved);
var svd=document.querySelector("#data-saved");
function saved(){
       svd.style.display="block" ;
}